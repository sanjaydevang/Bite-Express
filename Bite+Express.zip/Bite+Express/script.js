// Change greeting based on time of day
document.addEventListener("DOMContentLoaded", function () {
    const greetingElement = document.getElementById("dynamic-greeting");
    const currentHour = new Date().getHours();
    let greeting;

    if (currentHour < 12) {
        greeting = "Good Morning! Welcome to Bite Express";
    } else if (currentHour < 18) {
        greeting = "Good Afternoon! Welcome to Bite Express";
    } else {
        greeting = "Good Evening! Welcome to Bite Express";
    }

    greetingElement.textContent = greeting;
});

// Order tracking functionality
document.getElementById("track-order-btn").addEventListener("click", function () {
    const orderId = document.getElementById("order-id").value;
    const statusDiv = document.getElementById("order-status");

    if (orderId) {
        statusDiv.innerHTML = `<p>Your order #${orderId} is <strong>Out for Delivery</strong>.</p>`;
    } else {
        statusDiv.innerHTML = `<p>Please enter a valid Order ID.</p>`;
    }
});
